<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ProductContoller;

Route::prefix('v1')
    // ->middleware('auth:sanctum')
    ->group(function () {
        Route::apiResource('customers', CustomerController::class);
        Route::apiResource('products', ProductContoller::class);
    });
