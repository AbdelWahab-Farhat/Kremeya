<?php

namespace App\Services;

use App\Enums\Gender;
use App\Models\Customer;
use App\Models\User;
use App\Http\Resources\CustomerResource;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class CustomerService
{
    public function getAll(array $filters = [], int $perPage = 15): AnonymousResourceCollection
    {
        $query = Customer::query()->with(['user', 'region', 'city']);

        if (!empty($filters['search'])) {
            $s = trim($filters['search']);
            $query->where(function ($q) use ($s) {
                $q->where('name', 'like', "%{$s}%")
                  ->orWhere('phone', 'like', "%{$s}%")
                  ->orWhere('customer_code', 'like', "%{$s}%");
            });
        }

        if (!empty($filters['gender']))   $query->where('gender', $filters['gender']);
        if (!empty($filters['city_id']))  $query->where('city_id', $filters['city_id']);
        if (!empty($filters['region_id']))$query->where('region_id', $filters['region_id']);
        if (!empty($filters['user_id']))  $query->where('user_id', $filters['user_id']);

        return CustomerResource::collection($query->latest()->paginate($perPage));
    }

    public function create(array $validated): CustomerResource
    {
        $customer = DB::transaction(function () use ($validated) {

            $user = User::create([
                'name'     => $validated['name'] ?? null,
                'email'    => $validated['email'] ?? null,
                'password' => $validated['password'] ?? null,
            ]);


            return $user->customer()->create([
                'phone'     => $validated['phone'],
                'city_id'   => $validated['city_id'] ?? null,
                'region_id' => $validated['region_id'] ?? null,
                'gender'    => $validated['gender'] ?? Gender::OTHER->value,
            ]);
        });

        return new CustomerResource($customer->load(['user', 'region', 'city']));
    }

    public function update(Customer $customer, array $validated): CustomerResource
    {
        $customer = DB::transaction(function () use ($customer, $validated) {

            // user data (only if provided)
            $userData = [];
            if (array_key_exists('name', $validated))  $userData['name']  = $validated['name'];
            if (array_key_exists('email', $validated)) $userData['email'] = $validated['email'];
            if (!empty($validated['password']))        $userData['password'] = $validated['password'];

            if (!empty($userData)) {
                $customer->user->update($userData);
            }

            $customer->update([
                'phone'     => $validated['phone'] ?? $customer->phone,
                'city_id'   => $validated['city_id'] ?? $customer->city_id,
                'region_id' => $validated['region_id'],
                'gender'    => $validated['gender'] ?? $customer->gender,
            ]);

            return $customer->fresh()->load(['user', 'region', 'city']);
        });

        return new CustomerResource($customer);
    }
}
